#!/bin/bash

data_atual=$(date +'%H-%d-%m-%Y')

mkdir ~/${data_atual}
cp -r . ~/${data_atual}



