#!/bin/bash

ls ${1} >> out.txt

ls ${2} >> out.txt

ls ${3} >> out.txt

ls ${4} >> out.txt
