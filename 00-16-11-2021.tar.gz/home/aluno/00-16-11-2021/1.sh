#!/bin/bash

echo -e "\nVeja sempre o lado bom, em todas as coisas\n"
